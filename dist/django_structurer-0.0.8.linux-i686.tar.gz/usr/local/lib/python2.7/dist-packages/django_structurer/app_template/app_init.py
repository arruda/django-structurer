#Example of usage
#from my_model import MyModel, MyModel2
#from my_other_model import Other

